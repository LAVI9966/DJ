import React from 'react';
import { PDFDownloadLink, Document, Page, Text, View, StyleSheet, pdf } from '@react-pdf/renderer';

const styles = StyleSheet.create({
    page: {
        padding: 40,
        fontFamily: 'Helvetica',
        fontSize: 10,
        lineHeight: 1.5,
    },
    title: {
        fontSize: 22,  // Slightly increase the font size
        marginBottom: 20,
        testAlign: 'right',
        fontWeight: 900,  // Maximum bold weight
        fontFamily: 'Arial Black',  // Use a naturally bolder font like 'Arial Black'
    },
    sectionTitle: {
        fontSize: 13,
        marginBottom: 5,
        fontWeight: 'bold',
        fontFamily: 'Arial Black',
    },
    section: {
        marginBottom: 15,
    },
    text: {
        fontSize: 10,
        marginBottom: 10,
    },
    footer: {
        fontSize: 18,
        textAlign: 'center',
        marginTop: 'auto',
        color: 'black',
    },
    line: {
        marginVertical: 10,
        height: 1,
        backgroundColor: 'black',
    },
});


const LicenseDocument = () => (
    <Document>
        <Page size="A4" style={styles.page}>
            <Text style={styles.title}>DURSH: Premium License</Text>
            <View style={styles.section}>
                <Text style={styles.sectionTitle}>License Agreement</Text>

                {/* Line added below */}
                <View style={styles.line} />

                <Text style={styles.text}>
                    THIS LICENCE AGREEMENT is made on "DAY DATE YEAR" ("Effective Date") by and between "LEGAL NAME", professionally known as "STAGE NAME" and living at "ADDRESS", "COUNTRY" (hereinafter referred to as the "Licensee") and Durgesh Gurjar, professionally known as DURSH and living at 97/A, Pandit Dindayal Upadhyay Nagar, Sukhliya, Indore, India (hereinafter referred to as the "Licensor").
                    Licensor warrants that it controls the mechanical rights in and to the copyrighted musical works entitled "BEAT NAME" ("Composition") as of and prior to the date first written above.
                    The Composition, including the music thereof, was composed by Durgesh Gurjar ("Songwriter") managed under the Licensor.
                </Text>

                <Text style={styles.sectionTitle}>Master Use</Text>
                <Text style={styles.text}>
                    The Licensor hereby grants to Licensee a non-exclusive license (this "License") to record vocal synchronization to the Composition partly or in its entirety and substantially in its original form ("Master Recording").
                </Text>
                <Text style={styles.sectionTitle}>Distribution Rights</Text>
                <Text style={styles.text}>
                    The Licensor hereby grants to Licensee a non-exclusive license to use the Master Recording in the reproduction, duplication, manufacture, and distribution of phonograph records, cassette tapes, compact disk, digital downloads, other miscellaneous audio and digital recordings, and any lifts and versions thereof (collectively, the "Recordings", and individually, a "Recording") worldwide for the pressing or selling a total of 5000 copies of such Recordings or any combination of such Recordings.
                </Text>

                <Text style={styles.sectionTitle}>Streaming Rights</Text>
                <Text style={styles.text}>
                    Additionally, licensee shall be permitted to distribute unlimited free internet downloads or streams for non-profit and non-commercial use. This license allows 100000 monetized audio streams to sites like Spotify or Apple Music.
                </Text>

                <Text style={styles.sectionTitle}>Synchronization Rights</Text>
                <Text style={styles.text}>
                    The Licensor hereby grants limited synchronization rights for 1 monetized music video streamed online (YouTube, Vimeo, etc..) for 100000 streams in total on all websites. A separate synchronization license will need to be purchased for distribution of video to Television, Film or Video game.
                </Text>

                <Text style={styles.sectionTitle}>Performance Rights</Text>
                <Text style={styles.text}>
                    The Licensor here by grants to Licensee a non-exclusive license to use the Master Recording in unlimited non-profit performances, shows, or concerts. Licensee may not receive compensation from performances with this license.
                </Text>

                <Text style={styles.sectionTitle}>Broadcast Rights</Text>
                <Text style={styles.text}>
                    The Licensor hereby grants to Licensee broadcasting rights for 1 radio stations.
                </Text>

                <Text style={styles.sectionTitle}>Credit</Text>
                <Text style={styles.text}>
                    Licensee shall acknowledge the original authorship of the Composition appropriately and reasonably in all media and performance formats under the name "DURSH" in writing where possible and vocally otherwise.
                </Text>

                {/* Additional sections here */}
                {/* ... */}
            </View>

            <Text style={styles.footer}>This license is governed by the law of India.</Text>
        </Page>
    </Document>
);

const LicenseGenerator = () => {
    const handleSubmit = async () => {
        try {
            const pdfDoc = <LicenseDocument />;
            const pdfBlob = await pdf(pdfDoc).toBlob(); // Generate PDF Blob

            const formData = new FormData();
            formData.append('to', 'gehloadlavish@gmail.com');
            formData.append('subject', 'Hello, Product Information');
            formData.append('text', 'hahahahhahahahahahahhahahahhahahahahhahhahahahahahhahah');
            formData.append('html', `<h1>Mail Agya <h1>`);
            formData.append('attachment', pdfBlob, 'license_agreement.pdf');

            const response = await fetch('http://localhost:3000/send_email', {
                method: 'POST',
                body: formData,
            });

            const result = await response.text();
            if (response.ok) {
                console.log('Success:', result);
            } else {
                console.error('Error:', result);
            }
        } catch (error) {
            console.error('Request failed:', error);
        }
    };

    return (
        <div style={{ padding: '20px' }}>
            <PDFDownloadLink
                document={<LicenseDocument />}
                fileName="license_agreement.pdf"
                style={{
                    marginTop: '20px',
                    padding: '12px 24px',
                    backgroundColor: 'green',
                    color: 'white',
                    border: 'none',
                    borderRadius: '5px',
                    textDecoration: 'none',
                    fontSize: '16px',
                    transition: 'background-color 0.3s, transform 0.2s',
                    display: 'inline-block',
                }}
                onMouseEnter={(e) => (e.currentTarget.style.backgroundColor = '#0056b3')}
                onMouseLeave={(e) => (e.currentTarget.style.backgroundColor = 'green')}
            >
                {({ loading }) => (loading ? 'Generating...' : 'Download License')}
            </PDFDownloadLink>

            <button
                onClick={handleSubmit}
                className="bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded"
            >
                Send Email with License
            </button>
        </div>
    );
};

export default LicenseGenerator;
