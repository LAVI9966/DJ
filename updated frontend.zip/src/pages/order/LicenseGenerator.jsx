import React from 'react';
import { PDFDownloadLink, Document, Image, Page, Text, View, StyleSheet, pdf } from '@react-pdf/renderer';

const styles = StyleSheet.create({
    page: {
        padding: 40,
        fontFamily: 'Helvetica',
        fontSize: 10,
        lineHeight: 1.5,
    },
    title: {
        fontSize: 20,
        marginBottom: 20,
        textAlign: 'center',
        fontWeight: 'bold',
    },
    sectionTitle: {
        fontSize: 16,
        marginBottom: 5,
        fontWeight: 'bold',
    },
    section: {
        marginBottom: 15,
    },
    text: {
        marginBottom: 10,
    },
    footer: {
        fontSize: 18,
        textAlign: 'center',
        marginTop: 'auto',
        color: 'grey',
    },
});

const LicenseDocument = () => (
    <Document>
        <Page size="A4" style={styles.page}>
            <Text style={styles.title}>DURSH: Premium License</Text>
            <View style={styles.section}>
                <Text style={styles.sectionTitle}>License Agreement</Text>
                <Text style={styles.text}>
                    THIS LICENSE AGREEMENT is made on {new Date().toLocaleDateString()} ("Effective Date") by and between "Legal name",
                    professionally known as "Stage name" and living at "Address", "Country" (hereinafter referred to as the "Licensee") and
                    Durgesh Gurjar, professionally known as DURSH and living at Indore, India (hereinafter referred to as the "Licensor").
                </Text>
                <Image src="https://t.auntmia.com/nthumbs/2020-01-06/4887348/4887348_15.jpg" style={{ width: '100%', marginBottom: 10 }} />
            </View>
            <Text style={styles.footer}>This license is governed by the law of India.</Text>
        </Page>
    </Document>
);

const LicenseGenerator = () => {
    const handleSubmit = async () => {
        try {
            const pdfDoc = <LicenseDocument />;
            const pdfBlob = await pdf(pdfDoc).toBlob(); // Generate PDF Blob

            const formData = new FormData();
            formData.append('to', 'durshbeats@gmail.com');
            formData.append('subject', 'Hello, Product Information');
            formData.append('text', 'hahahahhahahahahahahhahahahhahahahahhahhahahahahahhahah');
            formData.append('html', `<h1>Mail Agya <h1>`);
            formData.append('attachment', pdfBlob, 'license_agreement.pdf');

            const response = await fetch('http://localhost:3000/send_email', {
                method: 'POST',
                body: formData,
            });

            const result = await response.text();
            if (response.ok) {
                console.log('Success:', result);
            } else {
                console.error('Error:', result);
            }
        } catch (error) {
            console.error('Request failed:', error);
        }
    };

    return (
        <div style={{ padding: '20px' }}>
            <PDFDownloadLink
                document={<LicenseDocument />}
                fileName="license_agreement.pdf"
                style={{
                    marginTop: '20px',
                    padding: '12px 24px',
                    backgroundColor: 'green',
                    color: 'white',
                    border: 'none',
                    borderRadius: '5px',
                    textDecoration: 'none',
                    fontSize: '16px',
                    transition: 'background-color 0.3s, transform 0.2s',
                    display: 'inline-block',
                }}
                onMouseEnter={(e) => (e.currentTarget.style.backgroundColor = '#0056b3')}
                onMouseLeave={(e) => (e.currentTarget.style.backgroundColor = 'green')}
            >
                {({ loading }) => (loading ? 'Generating...' : 'Download License')}
            </PDFDownloadLink>

            <button
                onClick={handleSubmit}
                className="bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded"
            >
                Send Email with License
            </button>
        </div>
    );
};

export default LicenseGenerator;
